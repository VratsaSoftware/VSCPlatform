var app = new Vue({
  el: '#app',
  data: {
  	cursorWep:'url(./img/sword2.png), auto',
  	cursorWepAttack:'url(./img/sword2_2.png), auto',
  	cursorWepBasic: 'url(./img/sword2.png), auto',
    health: 100,
    dead: false,
    lifecolor: 'green',	
    imgDino:'./img/Idle (1).png',
    imgHit: './img/Jump (5).png',
    imgDinoIdle:'./img/Idle (1).png',
    imgDinoDead:[
    	'./img/Dead (1).png',
    	'./img/Dead (2).png',
    	'./img/Dead (3).png',
    	'./img/Dead (4).png',
    	'./img/Dead (5).png',
    ],
    time:0,
    clicks:0,
    growingSpeed:5000,
  },
  mounted:function(){
  	     window.setInterval(() => {
                this.grow(1);
                this.timeSpend();
            },1000);
            
             window.setInterval(() => {
                this.grow(5);
            },this.growingSpeed);
  },
  methods: {
    dino_clicked: function (event) {
    	this.clicks++;
    	if(this.clicks > 50){
    		this.growingSpeed = 4500;
    	}
    	if(this.clicks > 70){
    		this.growingSpeed = 4000;
    	}
    	if(this.clicks > 100){
    		this.growingSpeed = 3500;
    	}
    	var audio = new Audio('sword.mp3');
        audio.play();
    	this.cursorWep = this.cursorWepAttack;
    	setTimeout(function(){
    		this.cursorWep = this.cursorWepBasic;
    	}.bind(this),300);
      if(!this.dead){
      this.health -= 1;
      this.imgDino = this.imgHit;
      setTimeout(function(){
                this.imgDino = this.imgDinoIdle;
            }.bind(this), 250);
      if (this.health <= 20) {
      	this.lifecolor = 'red';
      }

      if(this.health <= 0){
      	this.imgDinoDead.forEach((item)=>{
    		setTimeout(function(){
                this.imgDino = item;
            }.bind(this), 1000);
		});
		var audioDead = new Audio('dead.mp3');
        audioDead.play();
		this.dead = true;
		this.health = 0;
      }
      }
    },
    grow: function(growMe){
    	console.log(this.growingSpeed);
    	if(!this.dead){
    	  this.health += growMe;
        }
    },
    timeSpend: function(){
    	if(!this.dead){
    	  this.time += 1;
        }
    }
  }
})